package com.example.finalpdm

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DatosA : AppCompatActivity() {

    lateinit var dbHelperSocio : estructuraSocio
    lateinit var dbHelperLibro : estructuraLibro


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_datos)


    }






}