package com.example.finalpdm

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [FragmentoS.newInstance] factory method to
 * create an instance of this fragment.
 */
class FragmentoS : Fragment() {
    // TODO: Rename and change types of parameters
    lateinit var dbHelperSocio : estructuraSocio
    lateinit var dbHelperLibro : estructuraLibro
    lateinit var listaUsuarios : MutableMap<Int,String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
            dbHelperSocio= estructuraSocio(this.requireContext())
            dbHelperLibro=estructuraLibro(this.requireContext())
            val dbSocio = dbHelperSocio.readableDatabase
            val dbLibro = dbHelperLibro.readableDatabase
            val consulta = "SELECT ${Socio.ColumnaID}, ${Socio.ColumnaNombre} FROM ${Socio.TABLE_NAME}"
            val cursor= dbSocio.rawQuery(consulta, null)
            listaUsuarios= mutableMapOf()
                while (cursor.moveToNext()) {
                    val itemId = cursor.getInt(cursor.getColumnIndexOrThrow(Socio.ColumnaID))
                    val itemNombre = cursor.getString(cursor.getColumnIndexOrThrow(Socio.ColumnaNombre))
                    listaUsuarios.apply { this[itemId] = itemNombre }
                }
        Log.d("FRAGMENTO", listaUsuarios.toString())
            cursor.close()


        }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val menu = inflater.inflate(R.layout.fragment_fragmento_s, container, false)
        val contenedor : LinearLayout = menu.findViewById(R.id.LnContenedor)
        listaUsuarios.forEach{(id, nombre)->
            run {
                val btUsuario: Button = Button(this.requireContext())
                btUsuario.text = nombre
                btUsuario.setBackgroundColor(Color.BLUE)
                contenedor.addView(btUsuario)
                Log.d("BOTON", btUsuario.text.toString())
            }
        }
        return menu
    }

}