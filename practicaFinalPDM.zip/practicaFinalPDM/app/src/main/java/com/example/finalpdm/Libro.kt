package com.example.finalpdm

object Libro {
    const val TABLE_NAME = "Libro"
    const val ColumnaID = "ID"
    const val ColumnaTitulo = "Titulo"
    const val ColumnaGenero = "Genero"
    const val ColumnaIdSocio = "idSocio"

    public const val SQL_CREATE_ENTRIES =
        "CREATE TABLE ${Libro.TABLE_NAME} (" +
                "${Libro.ColumnaID} INTEGER PRIMARY KEY," +
                "${Libro.ColumnaTitulo} TEXT," +
                "${Libro.ColumnaGenero} TEXT," +
                "${Libro.ColumnaIdSocio} INTEGER)"

    public const val SQL_CREATE_DATA = "INSERT INTO ${Libro.TABLE_NAME} VALUES (11,'EL TITANIC','DRAMA',1)," +
            "(22,'SINISTER','MIEDO',1), (33, 'ASESINATO EN MANHATTAN','POLICIACA',1), " +
            "(44, 'SOMBRA Y HUESO','AVENTURA',2), " +
            "(55, 'SEIS DE CUERVOS','FANTASIA URBANA',2), (66, 'LA CANCION DE AQUILES','HISTORIA',3)"



    public const val SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS ${Libro.TABLE_NAME}"

}