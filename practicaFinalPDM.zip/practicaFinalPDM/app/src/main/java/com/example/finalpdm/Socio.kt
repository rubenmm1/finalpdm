package com.example.finalpdm

object Socio {
    const val TABLE_NAME = "Socio"
    const val ColumnaID = "ID"
    const val ColumnaNombre = "Nombre"
    const val ColumnaApellido = "Apellido"
    const val ColumnaEdad = "Edad"

    public const val SQL_CREATE_ENTRIES =
        "CREATE TABLE ${Socio.TABLE_NAME} (" +
                "${Socio.ColumnaID} INTEGER PRIMARY KEY," +
                "${Socio.ColumnaNombre} TEXT," +
                "${Socio.ColumnaApellido} TEXT," +
                "${Socio.ColumnaEdad} INTEGER)"

    public const val SQL_CREATE_DATA = "INSERT INTO ${Socio.TABLE_NAME} VALUES (1,'RUBEN','MARTIN',21)," +
            "(2,'FRANCISCO','RODRIGUEZ',22), (3, 'PACO','SANTANA',24)"

    public const val SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS ${Socio.TABLE_NAME}"

}